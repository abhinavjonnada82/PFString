#include "test_interface.hpp"

int main()
{
	runTests();

	return 0;
}
